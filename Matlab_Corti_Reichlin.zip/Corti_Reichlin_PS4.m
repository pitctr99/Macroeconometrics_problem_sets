%%%%%%%%%%%%%%%%%%%%%%%%% MACROECONOMETRICS PS4 %%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% Corti Pietro (3061891), Reichlin Vito (3081010) %%%%%%%%%%%%%

clear
P=genpath('C:\Users\pietr\OneDrive\Desktop\Macroeconometria\PS_2022'); addpath(P);


%% Point 4: Theoretical IRF

%Companion
c1 = [0 0;0.5 (7/12)];
c2 = [0.4 0.5;0 0];
C = [c1 c2; eye(2) zeros(2)];
irf = eye(2);
for n=2:40
    Cn = C^(n-1);
    irf(:,:,n)=Cn(1:2,1:2);
end
TIRF1 = squeeze(irf(1,1,:));
TIRF2 = squeeze(irf(1,2,:));
TIRF3 = squeeze(irf(2,1,:));
TIRF4 = squeeze(irf(2,2,:));

figure; title('Theoretical IRFs');
subplot(2,2,1);plot(TIRF1);
subplot(2,2,2);plot(TIRF2);
subplot(2,2,3);plot(TIRF3);
subplot(2,2,4);plot(TIRF4);


%% Point 5

%% a)
%% estimating a VAR in levels (lag)
T = 250;
mc = 1000;
IRF1_lev_storing = [];
IRF2_lev_storing = [];
IRF3_lev_storing = [];
IRF4_lev_storing = [];

for d=1:mc

% DGP
for t=3:T    
    eps = [randn(2,1)];
    yt(:,1) = eps;  
    yt(:,2) =  eps;
    yt(:,t) = [0 0; 0.5 7/12]*yt(:,t-1) + [0.4 0.5; 0 0]*yt(:,t-2) + eps;
end

Y = yt(1:2,1:end)';
Y1 = Y(:,1);
Y2 = Y(:,2);
VAR = varm(2,1);
EstVAR = estimate(VAR,[Y1, Y2]);
OLS = EstVAR.AR{1,1};

% To compute the IRF for the companion form we use the VMA representation
IRF_lev(:,:,1) = eye(2);
for n=1:500                                                                % sum of the coefficients for the VMA
    Bn = (OLS)^n;
    IRF_lev(:,:,n+1) = Bn;
end

% IRFs in levels
IRF1_lev = squeeze(IRF_lev(1,1,:));
IRF2_lev = squeeze(IRF_lev(1,2,:));
IRF3_lev = squeeze(IRF_lev(2,1,:));
IRF4_lev = squeeze(IRF_lev(2,2,:));

% Storing IRFs for the MC simulation
IRF1_lev_storing = [IRF1_lev IRF1_lev_storing];
IRF2_lev_storing = [IRF2_lev IRF2_lev_storing];
IRF3_lev_storing = [IRF3_lev IRF3_lev_storing];
IRF4_lev_storing = [IRF4_lev IRF4_lev_storing];

end
  
%% Means, CI and comparisons

%means
m_IRF1_lev = mean(IRF1_lev_storing, 2);
m_IRF2_lev = mean(IRF2_lev_storing, 2);
m_IRF3_lev = mean(IRF3_lev_storing, 2);
m_IRF4_lev = mean(IRF4_lev_storing, 2);

%confidence intervals
ci_IRF1_lev = prctile(IRF1_lev_storing, [2.5 97.5], 2);
ci_IRF2_lev = prctile(IRF2_lev_storing, [2.5 97.5], 2);
ci_IRF3_lev = prctile(IRF3_lev_storing, [2.5 97.5], 2);
ci_IRF4_lev = prctile(IRF4_lev_storing, [2.5 97.5], 2);

%% Plotting theoretical-level IRFs and estimated ones

l = 20; %periods to visualize
x=1:l;

tiledlayout(2,2)

ax1 = nexttile;
plot(ax1, x, m_IRF1_lev(1:l), x, ci_IRF1_lev(1:l,:), '--', x, TIRF1(1:l))
legend('Empirical IRF','2.5% bound','97.5% bound','Theoretical IRF')

ax2 = nexttile;
plot(ax2, x, m_IRF2_lev(1:l), x, ci_IRF2_lev(1:l,:), '--', x, TIRF2(1:l))


ax3 = nexttile;
plot(ax3, x, m_IRF3_lev(1:l), x, ci_IRF3_lev(1:l,:), '--', x, TIRF3(1:l))


ax4 = nexttile;
plot(ax4, x, m_IRF4_lev(1:l), x, ci_IRF4_lev(1:l,:), '--', x, TIRF4(1:l))



%% b)

%% New DGP
T = 250;
Y=[];
for t=1:1000  
y= zeros(2,2);
for n=3:T+3
    v = normrnd(0,1,[2,1]);
    y(:,n) = [0 0;0.5 (7/12)]*y(:,n-1)+[0.4 0.5;0 0]*y(:,n-2)+v;
end
Y(:,:,t)=y(:,4:end);
end

Z = [];
for n=2:length(Y(:,:,1))
    z = Y(:,n,:)-Y(:,n-1,:);
    Z = [Z z];
end

%% estimating a VAR in first difference (lag)
lag = 1;
VAR = varm(2,lag);
VAR.Constant = [0;0];
IRF1 = []; 
IRF2 = []; 
IRF3 = []; 
IRF4 = [];
for t=1:1000
X = Z(:,:,t)';
EstVAR = estimate(VAR, X);
B=[];
for s=1:lag
b = EstVAR.AR{1,s};
B(:,:,s)=b;
end
%irf
% automatic way to compute Companion form 
C = [];
for n = 0:lag
    C = [C; zeros(2, 2*n) eye(2) zeros(2,(lag-n)*2)];
end
c = (eye(2)+B(:,:,1));
for n = 2:lag
    c=[c (B(:,:,n)-B(:,:,n-1))];
end
c = [c -B(:,:,lag)];
C = [c; C];
C = C(1:end-2,:);
%
irf = eye(2);
for n=2:300
    Cn = C^(n-1);
    irf(:,:,n)=Cn(1:2,1:2);
end
IRF1 = [IRF1 squeeze(irf(1,1,:))];
IRF2 = [IRF2 squeeze(irf(1,2,:))];
IRF3 = [IRF3 squeeze(irf(2,1,:))];
IRF4 = [IRF4 squeeze(irf(2,2,:))];
end
%% mean and ci

m_IRF1 = mean(IRF1, 2);
m_IRF2 = mean(IRF2, 2);
m_IRF3 = mean(IRF3, 2);
m_IRF4 = mean(IRF4, 2);

ci_IRF1 = prctile(IRF1, [5 95], 2);
ci_IRF2 = prctile(IRF2, [5 95], 2);
ci_IRF3 = prctile(IRF3, [5 95], 2);
ci_IRF4 = prctile(IRF4, [5 95], 2);

% plotting
l = 20; % periods to visualize
x=1:l;

tiledlayout(3,2)

ax1 = nexttile;
plot(ax1, x, m_IRF1(1:l), x, ci_IRF1(1:l,:), '--', x, TIRF1(1:l))
title(ax1,'')
legend('Empirical IRF','5% bound','95% bound','Theoretical IRF')

ax2 = nexttile;
plot(ax2, x, m_IRF2(1:l), x, ci_IRF2(1:l,:), '--', x, TIRF2(1:l))
title(ax2,'')

ax3 = nexttile;
plot(ax3, x, m_IRF3(1:l), x, ci_IRF3(1:l,:), '--', x, TIRF3(1:l))
title(ax3,'')

ax4 = nexttile;
plot(ax4, x, m_IRF4(1:l), x, ci_IRF4(1:l,:), '--', x, TIRF4(1:l))
title(ax4,'')


%% c)
%% lags from 1 to 4

for lag=1:4

VAR = varm(2,lag);
VAR.Constant = [0;0];
IRF1 = []; 
IRF2 = []; 
IRF3 = []; 
IRF4 = [];
for t=1:1000
X = Z(:,:,t)';
EstVAR = estimate(VAR, X);
B=[];
for s=1:lag
b = EstVAR.AR{1,s};
B(:,:,s)=b;
end
%irf
% automatic way to compute Companion form 
C = [];
for n = 0:lag
    C = [C; zeros(2, 2*n) eye(2) zeros(2,(lag-n)*2)];
end
c = (eye(2)+B(:,:,1));
for n = 2:lag
    c=[c (B(:,:,n)-B(:,:,n-1))];
end
c = [c -B(:,:,lag)];
C = [c; C];
C = C(1:end-2,:);
%
irf = eye(2);
for n=2:300
    Cn = C^(n-1);
    irf(:,:,n)=Cn(1:2,1:2);
end
IRF1 = [IRF1 squeeze(irf(1,1,:))];
IRF2 = [IRF2 squeeze(irf(1,2,:))];
IRF3 = [IRF3 squeeze(irf(2,1,:))];
IRF4 = [IRF4 squeeze(irf(2,2,:))];
end
%% mean and ci

m_IRF1 = mean(IRF1, 2);
m_IRF2 = mean(IRF2, 2);
m_IRF3 = mean(IRF3, 2);
m_IRF4 = mean(IRF4, 2);

ci_IRF1 = prctile(IRF1, [5 95], 2);
ci_IRF2 = prctile(IRF2, [5 95], 2);
ci_IRF3 = prctile(IRF3, [5 95], 2);
ci_IRF4 = prctile(IRF4, [5 95], 2);
% plotting
l = 20; %periods to visualize
x=1:l;

hold on

ax1 = nexttile;
plot(ax1, x, m_IRF1(1:l), x, ci_IRF1(1:l,:), '--', x, TIRF1(1:l))
title(ax1,'')
legend('Empirical IRF','5% bound','95% bound','Theoretical IRF')

ax2 = nexttile;
plot(ax2, x, m_IRF2(1:l), x, ci_IRF2(1:l,:), '--', x, TIRF2(1:l))
title(ax2,'')

ax3 = nexttile;
plot(ax3, x, m_IRF3(1:l), x, ci_IRF3(1:l,:), '--', x, TIRF3(1:l))
title(ax3,'')

ax4 = nexttile;
plot(ax4, x, m_IRF4(1:l), x, ci_IRF4(1:l,:), '--', x, TIRF4(1:l))
title(ax4,'')

end 

hold off

%% d)
clear

%% DGP and theoretical IRFs
T = 250;
Y=[];
for t=1:1000  
y= zeros(2,2);
for n=3:T+3
    v = normrnd(0,1,[2,1]);
    y(:,n) = [0 0;0.5 (7/12)]*y(:,n-1)+[0.4 0.5;0 0]*y(:,n-2)+v;
end
Y(:,:,t)=y(:,4:end);
end

Z = [];
for n=2:length(Y(:,:,1))
    z = Y(:,n,:)-Y(:,n-1,:);
    Z = [Z z];
end


% Theoretical IRF
%Companion
c1 = [0 0;0.5 (7/12)];
c2 = [0.4 0.5;0 0];
C = [c1 c2; eye(2) zeros(2)];
irf = eye(2);
for n=2:300
    Cn = C^(n-1);
    irf(:,:,n)=Cn(1:2,1:2);
end
TIRF1 = squeeze(irf(1,1,:));
TIRF2 = squeeze(irf(1,2,:));
TIRF3 = squeeze(irf(2,1,:));
TIRF4 = squeeze(irf(2,2,:));



% Johansen MLE for ECM parameters

%% 1 Auxiliary regressions 
Y = Y(:,2:end,:);  
OLS_d = [];
for n=1:1000                                                               % this is the loop for pi in the lecture notes
    ols = Z(:,1:end-1,n)'\Z(:,2:end,n)';
    OLS_d(:,:,n) = ols';
end 
OLS_l= [];
for n= 1:1000                                                              % this is the loop for xi in the lecture nots
    ols = Z(:,1:end-1,n)'\Y(:,1:end-1,n)';
    OLS_l(:,:,n)=ols';
end 

%% 2 Canonical correlations and IRF
jIRF1 = []; 
jIRF2 = []; 
jIRF3 = []; 
jIRF4 = [];
for n=1:1000
    %derive residuals 
    u = Z(:,2:end,n)'- Z(:,1:end-1,n)'*OLS_d(:,:,n)';
    v = Y(:,1:end-1,n)'- Z(:,1:end-1,n)'*OLS_l(:,:,n)';
    uu = (1/249)*u'*u;
    vv = (1/249)*v'*v;
    uv = (1/249)*u'*v;
    S = inv(vv)*uv'*inv(uu)*uv;     
    [V,D]=eig(S);       %V is the matrix of eigenvector; D has eigenvalues on its diagonal
    V_hat = [(V(:,1)/sqrt(V(:,1)'*vv*V(:,1))) (V(:,2)/sqrt(V(:,2)'*vv*V(:,2)))];
    if D(1,1) > D(2,2)
        A = V_hat(:,1);
    else 
        A = V_hat(:,2);
    end
    
    % 3 Derive the MLE for the ECM parameters and compute IRF
    xi_zero = uv * A * A';
    xi_one = OLS_d(:,:,n)-xi_zero*OLS_l(:,:,n);
    omega = (1/249)*(u-v*xi_zero')'*(u-v*xi_zero);
    C = [(xi_zero+xi_one+eye(2)) -xi_one; eye(2) zeros(2)];
    irf = eye(2);
    for t=2:300
        Cn = C^(t-1);
        irf(:,:,t)=Cn(1:2,1:2);
    end
    jIRF1 = [jIRF1 squeeze(irf(1,1,:))];
    jIRF2 = [jIRF2 squeeze(irf(1,2,:))];
    jIRF3 = [jIRF3 squeeze(irf(2,1,:))];
    jIRF4 = [jIRF4 squeeze(irf(2,2,:))];
end

%% Mean and CI

m_IRF1 = mean(jIRF1, 2);
m_IRF2 = mean(jIRF2, 2);
m_IRF3 = mean(jIRF3, 2);
m_IRF4 = mean(jIRF4, 2);

ci_IRF1 = prctile(jIRF1, [5 95], 2);
ci_IRF2 = prctile(jIRF2, [5 95], 2);
ci_IRF3 = prctile(jIRF3, [5 95], 2);
ci_IRF4 = prctile(jIRF4, [5 95], 2);

%% Plotting
l = 20; % periods to visualize
x=1:l;

tiledlayout(3,2)

ax1 = nexttile;
plot(ax1, x, m_IRF1(1:l), x, ci_IRF1(1:l,:), '--', x, TIRF1(1:l))
title(ax1,'')
legend('Empirical IRF','5% bound','95% bound','Theoretical IRF')

ax2 = nexttile;
plot(ax2, x, m_IRF2(1:l), x, ci_IRF2(1:l,:), '--', x, TIRF2(1:l))
title(ax2,'')

ax3 = nexttile;
plot(ax3, x, m_IRF3(1:l), x, ci_IRF3(1:l,:), '--', x, TIRF3(1:l))
title(ax3,'')

ax4 = nexttile;
plot(ax4, x, m_IRF4(1:l), x, ci_IRF4(1:l,:), '--', x, TIRF4(1:l))
title(ax4,'')



%% Johansen procedure (command), this is an extra
clear

T=250;

% DGP
for t=3:T    
    eps = [randn(2,1)];
    yt(:,1) = eps;  
    yt(:,2) =  eps;
    yt(:,t) = [0 0; 0.5 7/12]*yt(:,t-1) + [0.4 0.5; 0 0]*yt(:,t-2) + eps;
end

Y = yt(1:2,1:end)';

% here we present the command that allows to obtain both the "trace" and "maxeig" tests
[h,pValue,stat,cValue] = jcitest(Y,Test=["trace" "maxeig"],Alpha=0.05);
display(h);
% in particular both test shows that the model has rank 1 for cointegration

