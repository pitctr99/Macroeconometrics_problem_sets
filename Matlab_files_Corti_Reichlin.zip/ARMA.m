
%esercizio 4

function [x, w] = ARMA(var, T, AR, MA, rootsAR, rootsMA);  
%the function outputs are: the generated observations from the ARMA (x) and the white noises (w)
%the function inputs are:
% the variance of the white noises (var)
% the number of generated observations (T)
% the coefficients of the AR polynomials (AR) or their roots (rootsAR)
% the coefficents of the MA polynomial (MA) or their roots (rootsMA)

if AR == 0                     %the function checks whether the inputted AR is equal to zero
    AR = poly(rootsAR);        % if AR is zero it computes the polynomail coefficients from the AR roots
elseif rootsAR==0              % then it's also checked whether roots AR is equal to zero
    AR = 0;                    % if Roots AR is also equal to zero then the function sets AR = 0
end
end
                       
if MA == 0                     %The same is done for the MA part  
    MA = poly(rootsMA);
elseif rootsMA==0
    MA = 0
end


AR2 = [AR zeros(1, T -  size(AR,2))];  % it creates an array of lenght T, with the first p positions occupied by the AR polynomial coefficents and the rest by zeros

MA2 = [MA zeros(1, T -  size(MA,2))];  % it creates an array of lenght T, with the first q positions occupied by the MA polynomial coefficents and the rest by zeros

x= zeros(1, T); % creates an array of lenght T filled with zeros 
w= zeros(1, T);  % same 
u= []; %creates an empty array
z=[];  % same 

for t = 1:T                                 % initialize the for cycle to generate T observations from the ARMA
    e = normrnd(0,var);                     % generate current period white noise 
    y = x * AR2' + w * MA2'+ e;             % ARMA equation: generates current period observation y
    z = [y z];                              % array z saves all the generated points
    x = [z zeros(1, T - size(z,2))];        % modify x to include generated points: notice that the array always begins with the latest point generated 
    u=[e u];                                % array u saves generated white noises
    w = [u zeros(1, T - size(u,2))];        % modify w to include generated white noises: notice that the array always begins with the latest white noise generated   
end

