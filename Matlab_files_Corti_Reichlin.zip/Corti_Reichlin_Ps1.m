%%%%%%%%%%%%%%%%%% PROBLEM SET 1: MACROECONOMETRICS 2022\2023 %%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%% Corti Pietro (3061891), Reichlin Vito (3081010) %%%%%%%%%%%%%%

clear

P=genpath('C:\Users\pietr\OneDrive\Desktop\Macroeconometria\PS_2022'); addpath(P);

% Point 1

%% a) 

N=500;
eps1=normrnd(0,.2,N,1);
Yt1=eps1(1,1);              
phi=0.4;

for t=2:N
    Yt1(t,1) = phi*Yt1(t-1,1) + eps1(t,1);
end


%% b) 

Yt_f1=filter(1,[1 -phi],eps1);
%%

% c)

figure('Name','AR processes')

plot(Yt1,'Color','red')                      % here the starting condition and the variable eps1 is the same in both processes
hold on
plot(Yt_f1,'Color','blue')
hold off
%% 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Point 2

eps2=normrnd(1.8,.2,N,1);                    % new DGP with mean=3
eps2(1,1)=10;                                % starting condition
Yt2=eps2(1,1);

for t=2:N
    Yt2(t,1) = phi*Yt2(t-1,1) + eps2(t,1);     %loop and initial condition
end
figure('Name','AR loop initial condition')
plot(Yt2)

figure('Name','AR adjusted')                   % adjusting the initial condition
yt_adj=Yt2(end-N+4:end,1);
plot(yt_adj)


eps2=normrnd(1.8,.2,1,N-1);
eps=[10 eps2];
Yt_f2=filter(1,[1 -phi],eps');                  %filter and initial condition

figure('Name','AR filter initial condition')
plot(1:500,Yt_f2)

%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Point 3

% a)

rng('default');

%method one, using a for loop in a recursive structure
n=500;                    %set the number of observations to generate
x = [];                   %create an empty array to be filled by the generated data
u=0;                      %set an intial value of the lagged white noise term

for t = 1:n 
    e = normrnd(0,0.3);   %current white noise is randomly selected from a normal distribution with mean zero and sigma^2 0.3
    y = 0.3 * u + e;      % equation of the MA process, with coefficient for the lagged term equal to 0.3
    x = [x, y];           %fill the array x with new observation generated
    u=e;                  %set the lagged white noise term for the next period equal to this period white noise
end

%%

% b)

x = normrnd(0, 0.3, 1, 500);   %generate 500 observations froma normal distribution with mean zero and sigma^2 equal to 0.3. These will be the White noise of the MA        
y = filter([1 .3], 1, x);      % use the function filter to generate the MA(1) process
y

%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Point 4

% for this point you can see the function "ARMA" in the folder we sent.
[x, w] = ARMA(var, T, AR, MA, rootsAR, rootsMA); 

%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Point 5

% a)-b)

for s=1:10000                      % creation of a loop to compute the empirical distribution of the OLS
T=250;                             % number of time observations
T_eff=T-1;                         % effective sample size for estimation (p=1 in this AR process)
DGP=randn(T,1);                    % here we use a randn to generate the process
phi=0.4;                           % setting the value for phi
Y_DGP= filter(1,[1 -phi],DGP);     % create the AR(1) DGP process
Xt=lagmatrix(Y_DGP,1:1);           % using the econometric toolbox we create the lags of the AR(1) process
Xt=[ones(T,1) Xt];                 % we add constants to the AR process
Yt=Y_DGP(2:end,1);                 % this commands cancel the initial p=1 +1  observations for the DGP
Xt=Xt(2:end,:);                    % this commands cancel the initial p=1 +1  observations for the DGP 
invXt=inv(Xt'*Xt);                 % this is the inverse part for the OLS                
phi_hat(:,s)=Xt\Yt;                % this is the OLS
T=200;                             % change time obs for point b)    
y_hat=Xt*phi_hat(:,s);             % this is the predicted value of the AR process             
eps_hat=Yt-y_hat;                  % this is the error term
ee=eps_hat'*eps_hat;               % this is the product of the errors
var_eps_hat=ee/(T_eff -1 -1);      % variance of the error term (we consider the constants, so we need to subtract another time at the denominator)
sig_eps_hat=sqrt(var_eps_hat);     % std dev of the error term 

var_phi_hat=var_eps_hat*invXt(2,2);          % var of the estimator
sig_phi_hat=sqrt(var_phi_hat);               % std dev of the estimtor

t_stat(s)=(phi_hat(2,s)-0)/sig_phi_hat;        % t-test
critical=tinv(0.05/2,T_eff-1-1);               % critical values
end

figure('Name','OLS Distribution')
[N,Z] = hist(phi_hat(2,:),30);                     % empirical distribution of the AR(1) with phi=0.4
plot(Z,N/10000);title('OLS distribution');grid

reject=sum(abs(t_stat)>1.96);                      % rejection of the null HP: phi=0: here we exploit the fact that if the inequality is true, sum gives one
rej_ratio=reject/10000;

%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Point 6

clearvars

for T=[50 100 200 1000]
    for s=1:10000
        DGP=randn(T,1);                    % here we use a randn to generate the process
        phi=0.9;                           % setting the value for phi
        Y_DGP= filter(1,[1 -phi],DGP);     % create the AR(1) DGP process
        Xt=lagmatrix(Y_DGP,1:1);           % using the econometric toolbox we create the lags of the AR(1) process
        Xt=[ones(T,1) Xt];                 % we add constants to the AR process
        Yt=Y_DGP(2:end,1);                 % this commands cancel the initial p=1 +1  observations for the DGP
        Xt=Xt(2:end,:);                    % this commands cancel the initial p=1 +1  observations for the DGP              
        phi_hat(:,s)=Xt\Yt;                % this is the OLS
    end
    [N,X] = hist(phi_hat(2,:),30);                                    % empirical distribution of the AR(1) with phi=0.4
    plot(X,N/10000);title('OLS distribution with different T');grid
    hold on
end
hold off

%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Point 7

% a)

clearvars 

rng('default');

T= 251;  % T is 251 to allow both the dependent and independent (lagged version of the dependent) vectors to have 250 observation each.          

A=[];                                  %create an empty array
for s=1:1000                           % initialize for cycle to create 1000 estimations of a 
x = normrnd(0, 1, 1, T);               % white noises of the MA(1)
y = filter([1 .6], 1, x);              % generates full MA(1) process using filter function with lagged coefficient equal to 0.6 
Yt = (y(2:T))';                        % select the dependent vector: take the last T-1 observations from y
Xt = (y(1:T-1))';                      % select the independent vector: take the first T-1 observations from y (lagged version of Yt)
[a,~,~] = regression_luca(Yt,Xt);      % function output is the estimated coefficient (a) for the regression
A=[A a];                               % stores the estimated coefficient 
end
A_mean = mean(A)                                   % compute the mean of the array A (which stored all the estimates for a)
figure;histogram(A); title('Histogram for a');     % histogram of the estimates for a 

%%

% b)

rng('default');
means=[];
for T = 251:10:2001                                % let T be recursive, going from 251 to 2001 by steps of 10
A=[];
for s=1:1000
x = normrnd(0, 1, 1, T);         
y = filter([1 .6], 1, x);
Yt = (y(2:T))';
Xt = (y(1:T-1))';
[a,~,~] = regression_luca(Yt,Xt);
A=[A a];
end
A_mean = mean(A);
means = [means A_mean];
end

size(means,2)
means(176)
t = 251:10:2001;                                                       %create the x axis for all values of T
figure; plot(t,means); title("means of a with increasing sample size") %plots the average a of each sample size inputted

%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Point 8

% a)

clearvars

for s=1:10000                      % creation of a loop to compute the empirical distribution of the OLS
T=250;                             % number of time observations                    
DGP=randn(T,1);                    % here we use a randn to generate the process
phi=1;                             % setting the value for phi
Y_DGP= filter(1,[1 -phi],DGP);     % create the AR(1) DGP process
Xt=lagmatrix(Y_DGP,1:1);           % using the econometric toolbox we create the lags of the AR(1) process
Xt=[ones(T,1) Xt];                 % we add constants to the AR process
Yt=Y_DGP(2:end,1);                 % this commands cancel the initial p=1 +1  observations for the DGP
Xt=Xt(2:end,:);                    % this commands cancel the initial p=1 +1  observations for the DGP 
phi_hat(:,s)=Xt\Yt;  
end

figure('Name','OLS Distribution phi=1')
[N,X] = hist(phi_hat(2,:),30);                             % empirical distribution of the AR(1) with phi=1
plot(X,N/10000);title('OLS distribution with phi=1');grid

%%

% b)

clearvars

for s=1:10000                      % creation of a loop to compute the empirical distribution of the OLS and the rejection
T=250;                             % number of time observations (not directly specified, but we suppose so from the text)
T_eff=T-1;                         % effective sample size for estimation (p=1 in this AR process)
DGP=randn(T,1);                    % here we use a randn to generate the process
phi=1;                             % setting the value for phi
Y_DGP= filter(1,[1 -phi],DGP);     % create the AR(1) DGP process
Xtr=lagmatrix(Y_DGP,1:1);          % using the econometric toolbox we create the lags of the AR(1) process
Xt=[ones(T,1) Xtr];                % we add constants to the AR process
Yt=Y_DGP(2:end,1);                 % this commands cancel the initial p=1 +1  observations for the DGP
Xt=Xt(2:end,:);                    % this commands cancel the initial p=1 +1  observations for the DGP
Xtr=Xtr(2:end,1);                  % this commands cancel the initial p=1 +1  observations for the DGP
Y=Yt-Xtr;                          % with this subtraction we can express the LHS of the regression as a difference
invXt=inv(Xt'*Xt);                 % this is the inverse part for the OLS                
rho_hat(:,s)=Xt\Y;                 % this is the OLS                            
y_hat=Xt*rho_hat(:,s);             % this is the predicted value of the AR process             
eps_hat=Y-y_hat;                   % this is the error term
ee=eps_hat'*eps_hat;               % this is the product of the errors
var_eps_hat=ee/(T_eff -1 -1);      % variance of the error term (we consider the constants, so we need to subtract another time at the denominator)
sig_eps_hat=sqrt(var_eps_hat);     % std dev of the error term 

var_rho_hat=var_eps_hat*invXt(2,2);          % var of the estimator
sig_rho_hat=sqrt(var_rho_hat);               % std dev of the estimtor

t_stat(s)=(rho_hat(2,s)-(phi-1))/sig_rho_hat;      % t-test
critical=tinv(0.05,T_eff-1-1);                     % critical values for a one sided test here (even if not strictly required)
end

reject=sum(abs(t_stat)>1.96);                % here we compute the rejection of H0 and its ratio
rej_ratio=reject/10000;                     


figure
h1=histogram(t_stat,30,'FaceColor','yellow'); title('T-Stat Distribution: DF and N(0,1)');
hold on
h2=histogram(randn(10000,1),30,'FaceColor','red');
hold off

%%

% c)

P=prctile(t_stat, [1 5 10 25 50 75 90 95])

%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Point 9

% a)-b)

clearvars

T=250;
T_eff=T-1;             % correct sample size for an AR(1) process
simu=5000;            % number of simulations we want to run
delta=0.4;             % value of the drift (not specified in the text)
phi=1;                 % this is a random walk, so the coeff is 1

for s=1:simu
    DGP=randn(T,1);                       % this random value generate the AR data
    Y_DGP= filter(1,[1 -phi],DGP+delta);  % this is the DGP for the RW with drift 
    Xtr=lagmatrix(Y_DGP,1:1);             % lag of the observations
    Xt=[ones(T,1) (1:T)' Xtr];            % we add constants to the RW process
    Yt=Y_DGP(2:end,1);                    % this commands cancel the initial p=1 +1  observations for the DGP
    Xt=Xt(2:end,:);                       % this commands cancel the initial p=1 +1  observations for the DGP
    Xtr=Xtr(2:end,1);                     % setting the dimension
    Y=Yt-Xtr;                             % setting the LHS for the unit root test
    invXt=inv(Xt'*Xt);                    % this is the inverse part for the OLS 

    theta_hat(:,s)=Xt\Y;               % this is the OLS                            
    y_hat=Xt*theta_hat(:,s);           % this is the predicted value of the AR process             
    eps_hat=Y-y_hat;                   % this is the error term
    ee=eps_hat'*eps_hat;               % this is the product of the errors
    var_eps_hat=ee/(T_eff -1 -1);      % variance of the error term (we consider the constants, so we need to subtract another time at the denominator)
    sig_eps_hat=sqrt(var_eps_hat);     % std dev of the error term 

    var_theta_hat=var_eps_hat*invXt(2,2);          % var of the estimator
    sig_theta_hat=sqrt(var_theta_hat);             % std dev of the estimtor

    DF(s)=(theta_hat(3,s)-(phi-1))/sig_theta_hat;                                          % DF-test
    F_test(s)=(theta_hat(3,s)-(phi-1))'*inv(var_theta_hat)*(theta_hat(3,s)-(phi-1))/2;     % F-test
                                                                
end

f_critical=finv(0.95,248,2);                 % critical values for F-test with 248 df for the num and 2 for the denom
reject=sum(F_test>6.34);                % here we compute the rejection of H0 and its ratio; 6.34 is the critical value for the DF test with T=250 and alpha=5%. See Hamilton (1994) pag. 764, table B.7 
rej_ratio=reject/simu;

figure
hist(theta_hat(3,:),30); title('Monte Carlo simulation for the RW')

figure
hist(F_test,80); title('Monte Carlo simulation for the F-test')

%%

% c)

clearvars

T=250;
T_eff=T-1;             % correct sample size for an AR(1) process
simu=50000;            % number of simulations we want to run (same as in the TA)
phi=1;                 % this is a random walk, so the coeff is 1
alpha=0.2;             % here we choose the values of the coeffiients (not specified in the text, so delta is the same of previous point 
delta=0.4;
for s=1:simu
    eps=randn(T,1);

    for t=2:T                                       % here starts the DGP with a time trend (we use 250 time periods)
        Y_DGP(t,1)= alpha + delta*t + eps(t,1);
    end

    Xtr=lagmatrix(Y_DGP,1:1);             % lag of the observations
    Xt=[ones(T,1) (1:T)' Xtr];            % we add constants to the RW process
    Yt=Y_DGP(2:end,1);                    % this commands cancel the initial p=1 +1  observations for the DGP
    Xt=Xt(2:end,:);                       % this commands cancel the initial p=1 +1  observations for the DGP
    Xtr=Xtr(2:end,1);                     % setting the dimension
    Y=Yt-Xtr;                             % setting the LHS for the unit root test
    invXt=inv(Xt'*Xt);                    % this is the inverse part for the OLS 

    theta_hat(:,s)=Xt\Y;               % this is the OLS                            
    y_hat=Xt*theta_hat(:,s);           % this is the predicted value of the AR process             
    eps_hat=Y-y_hat;                   % this is the error term
    ee=eps_hat'*eps_hat;               % this is the product of the errors
    var_eps_hat=ee/(T_eff -1 -1);      % variance of the error term (we consider the constants, so we need to subtract another time at the denominator)
    sig_eps_hat=sqrt(var_eps_hat);     % std dev of the error term 

    var_theta_hat=var_eps_hat*invXt(2,2);          % var of the estimator
    sig_theta_hat=sqrt(var_theta_hat);             % std dev of the estimtor

    DF(s)=(theta_hat(3,s)-(phi-1))/sig_theta_hat;                                           % DF-test
    F_test(s)=(theta_hat(3,s)-(phi-1))'*inv(var_theta_hat)*(theta_hat(3,s)-(phi-1))/2;      % F-test
end 

figure
hist(theta_hat(3,:),30); title('MC simulation for the deterministic time trend')

figure
hist(F_test,80); title('MC simulation for the F-test in deterministic time trend')

f_critical=finv(0.95,248,2);            % critical values for F-test with 248 df for the num and 2 for the denom
reject=sum(F_test>6.34);                % here we compute the rejection of H0 and its ratio
rej_ratio=reject/simu;
